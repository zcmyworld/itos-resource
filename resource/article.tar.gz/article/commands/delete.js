import ITOS from '@/ITOS';

export default {
  exec(route_path) {
    ITOS.Router.change(route_pat);
  }
}
